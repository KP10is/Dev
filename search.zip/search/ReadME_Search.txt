
Dans js/livesearch.js
Dans home/links.xml
Dans home/livesearch.php


Dans header.php il faut mettre ce div 

<div id="livesearch"></div>

Il faut v�rifier que les titres dans le fichier xml, sont les m�mes que les noms des pages